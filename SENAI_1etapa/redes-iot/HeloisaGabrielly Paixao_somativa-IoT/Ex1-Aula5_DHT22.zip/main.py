from machine import Pin
from utime import sleep
from dht import DHT22

sensor_temp = DHT22(Pin(15))
led_atencao = Pin(14,Pin.OUT)

while True:
    sensor_temp.measure()
    temperatura = sensor_temp.temperature()
    umidade = sensor_temp.humidity()

    if temperatura > 30:
        print('ALERTA, temperatura muito alta!')
        led_atencao.on()

    else:
        print(f'A temperatura atual é de {temperatura} ºC.')
        print(f'A umidade atual é de {umidade:.2%}.')
        led_atencao.value(0)
    sleep(1)