from machine import Pin
from utime import sleep

# Configura o pino do sensor PIR como entrada
pir = Pin(15, Pin.IN)

while True:
    if pir.value() == 1:
        print("Movimento detectado!")
    else:
        print("Nenhum movimento.")
    
    sleep(1)