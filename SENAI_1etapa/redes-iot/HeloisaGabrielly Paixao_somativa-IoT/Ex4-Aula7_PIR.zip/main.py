from machine import Pin
from utime import sleep

#vai ligar a lâmpada
rele = Pin(16, Pin.OUT)
#sensor que vai detectar presença
sensor_presenca = Pin(15, Pin.IN)

while True:
    #aqui vamos guardar o valor da PIR
    detectar = sensor_presenca.value()
    #se detectar presença, liga a LÂMPADA (o RELE liga ela)
    if detectar == 1:
        rele.on()
        print("Foi detectado um movimento", sensor_presenca.value())
    else:
        rele.off()
        print("Não foi detectado nenhum movimento", sensor_presenca.value())

    sleep(1)