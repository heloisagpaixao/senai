from machine import Pin, PWM, ADC
from time import sleep
import math

servo = PWM(Pin(15))
servo.freq(50)
sensor_gas = ADC(26)

RL = 5000
R0 = 10000

m = -0.42
b = 1.92  

while True:
    leitura = sensor_gas.read_u16()
    print("Nível de gás/fumaça:", leitura)
    
    leitura = sensor_gas.read_u16()
    tensao = (leitura / 65535) * 3.3
    rs = (3.3 - tensao) * RL / tensao
    razao = rs / R0
    ppm = 10 ** ((math.log10(razao) - b) / m)

    if ppm >= 30000:
        print("O nível está muito alto!")
        servo.duty_ns(1500000)
        sleep(1)
        servo.duty_ns(2400000)
        sleep(5)

    else:
        servo.duty_ns(1500000)
        print("O nível está OK.")
    sleep(0.1)