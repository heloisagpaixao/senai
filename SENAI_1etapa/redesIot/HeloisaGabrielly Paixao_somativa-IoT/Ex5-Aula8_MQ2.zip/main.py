from picozero import Speaker
from machine import Pin, ADC
from utime import sleep
import math 

led = Pin(15, Pin.OUT)
buzzer = Speaker(14)
sensor_gas = ADC(26) 

RL = 5000
R0 = 10000

m = -0.42
b = 1.92  

while True:
    leitura = sensor_gas.read_u16()
    print("Nível de gás/fumaça:", leitura)
    sleep(1)
    
    leitura = sensor_gas.read_u16()
    tensao = (leitura / 65535) * 3.3
    rs = (3.3 - tensao) * RL / tensao
    razao = rs / R0
    ppm = 10 ** ((math.log10(razao) - b) / m)

    if ppm >= 30000:
        buzzer.on()
        led.on()
        print("O nível de gás está muito alto!")
    elif ppm < 30000:
        buzzer.off()
        led.off()
        print("O nível de gás está normal!")

    sleep (0.1)